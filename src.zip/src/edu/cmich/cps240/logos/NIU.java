package edu.cmich.cps240.logos;

import edu.cmich.cps240.game.Board;

public class NIU extends Logo {

	public NIU(Board board) {
		super(board, "northern_ill.png","NIU");
		// TODO Auto-generated constructor stub
	}

}
