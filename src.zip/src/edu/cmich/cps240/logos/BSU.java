package edu.cmich.cps240.logos;

import edu.cmich.cps240.game.Board;

public class BSU extends Logo {

	public BSU(Board board) {
		super(board, "ball_state.png","BSU");
		// TODO Auto-generated constructor stub
	}

}
