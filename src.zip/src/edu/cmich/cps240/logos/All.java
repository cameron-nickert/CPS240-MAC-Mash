package edu.cmich.cps240.logos;

import edu.cmich.cps240.game.Board;

public class All extends Logo {

	public All(Board board) {
		super(board, "mystery.png","All");
		// TODO Auto-generated constructor stub
	}

}
