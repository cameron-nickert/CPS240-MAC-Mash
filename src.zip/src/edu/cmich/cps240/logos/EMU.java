package edu.cmich.cps240.logos;

import edu.cmich.cps240.game.Board;

public class EMU extends Logo  {

	public EMU(Board board) {
		super(board, "eastern_mich.png","EMU");
		// TODO Auto-generated constructor stub
	}

}
