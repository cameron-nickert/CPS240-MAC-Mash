package edu.cmich.cps240.logos;

import edu.cmich.cps240.game.Board;

public class TOL extends Logo {

	public TOL(Board board) {
		super(board, "toledo.png","TOL");
		// TODO Auto-generated constructor stub
	}

}
