package edu.cmich.cps240.logos;

import edu.cmich.cps240.game.Board;

public class CMU extends Logo {

	public CMU(Board board) {
		super(board, "central_mich.png","CMU");
		// TODO Auto-generated constructor stub
	}

}
