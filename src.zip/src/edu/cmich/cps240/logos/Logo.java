package edu.cmich.cps240.logos;

import edu.cmich.cps240.game.*;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.effect.DropShadow;

public class Logo extends Button {

	protected String image;
	private int phyX;
	private int phyY;
	private int x;
	private int y;
	private String type;
	public boolean isRemoving = false;
	public boolean isAnimated;
	final protected int size = 62;
	public ImageView iconView;
	
	
	public Logo(Board board, String imageFilePath, String type) {
		this.isAnimated = false;
		this.image = imageFilePath;
		this.type = type;
		this.setWidth(size);
		this.setHeight(size);
		this.setStyle("-fx-background-color: transparent;");// makes the button
															// itself
															// transparent

		// the college logo goes here
		Image icon = new Image(getClass().getResourceAsStream(this.image)); // creates
																			// the
																			// image
																			// file
		iconView = new ImageView(icon); // creates a node so it can be added to
										// the button
		iconView.setFitHeight(size); // modifies image to be correct suze
		iconView.setFitWidth(size);
		this.setGraphic(iconView); // adds the icon to the button
		
		
		this.setOnMousePressed(e -> {
			if(!board.buttonsEnabled || isAnimated || isRemoving) {
				// removes all effects
				ObservableList<Node> logos = board.getChildren();
				for (Node node : logos) {
					Logo logo = (Logo) node;
					logo.iconView.setEffect(null);
					logo.setEffect(null);
					logo.setDisabled(false);
				}
				board.clickDefaults();
				return;
			}

			if (board.clickNumber == 0) {
				board.buttonsEnabled = false;
				board.firstClickedLogo = this;
				board.clickNumber = 1;
				DropShadow shadow = new DropShadow();
				shadow.setSpread(.75);

				ObservableList<Node> logos = board.getChildren();
				for (Node node : logos) {
					Logo logo = (Logo) node;
					if(!logo.isVisible())
						continue;
					
					if (!(Math.abs(logo.getX() - this.getX()) == 1
							&& Math.abs(logo.getY() - this.getY()) == 0)
							&& !(Math.abs(logo.getX() - this.getX()) == 0
									&& Math.abs(logo.getY() - this.getY()) == 1)) {
						logo.setDisabled(true);
					} else {
						logo.iconView.setEffect(shadow);
					}
				}
				
				this.iconView.setEffect(shadow);
				this.setDisabled(false);
			}
		});

		this.setOnMouseEntered(e -> {
			if(board.buttonsEnabled || isRemoving || board.firstClickedLogo==null) {
				// removes all effects
				ObservableList<Node> logos = board.getChildren();
				for (Node node : logos) {
					Logo logo = (Logo) node;
					logo.iconView.setEffect(null);
					logo.setEffect(null);
					logo.setDisabled(false);
				}
				board.clickDefaults();
				return;
			}
			
			
			if (board.clickNumber != 0) {
				board.clickNumber = 0;
				// it is eligible if the shadow effect is on it
				boolean disabled = this.isDisabled();

				// removes all effects
				ObservableList<Node> logos = board.getChildren();
				for (Node node : logos) {
					Logo logo = (Logo) node;
					logo.iconView.setEffect(null);
					logo.setEffect(null);
					logo.setDisabled(false);
				}

				// if its not an eligible click, undo it all
				
				if (board.firstClickedLogo.equals(this) || disabled) {
					board.clickDefaults();
					return;
				}
				board.secondClickedLogo = this;

				board.swapTwoLogos(); //this function will check scores after its called
				
				//this delays until the two logos have swaped


			}

		});
		
		
		
		
		
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getPhyX() {
		return phyX;
	}

	public void setPhyX(int phyX) {
		this.phyX = phyX;
	}

	public int getPhyY() {
		return phyY;
	}

	public void setPhyY(int phyY) {
		this.phyY = phyY;
	}

	public String getType() {
		return type;
	}

	
	//this will return any logos that are surronding this one
	public Logo[] getDirections(Board board) {
		Logo[] directionArray = {null,null,null,null};
		
		ObservableList<Node> logos = board.getChildren();
		for (Node node : logos) {
			Logo logo = (Logo) node;
			if(logo.isRemoving || this.getType() != logo.getType()) {
				continue;
			}
			
			if(this.getY()-logo.getY()==0) {
				if(this.getX()-logo.getX()==1) { //left
					directionArray[0] = logo;
				} else if(this.getX()-logo.getX()==-1) { //right
					directionArray[1] = logo;
				}
			} else if(this.getX()-logo.getX()==0) {
				if(this.getY()-logo.getY()==1) { //up
					directionArray[2] = logo;
				} else if(this.getY()-logo.getY()==-1) { //down
					directionArray[3] = logo;
				}
			}
		}
		return directionArray;

	}
	
	
	
	
	
}
