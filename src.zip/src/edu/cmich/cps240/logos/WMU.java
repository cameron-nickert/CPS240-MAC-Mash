package edu.cmich.cps240.logos;

import edu.cmich.cps240.game.Board;

public class WMU extends Logo {

	public WMU(Board board) {
		super(board, "western_mich.png","WMU");
		// TODO Auto-generated constructor stub
	}

}
