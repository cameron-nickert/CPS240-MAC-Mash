package edu.cmich.cps240.game;

import java.net.URL;

import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.ImageCursor;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Game extends Application {

	LevelLoader levelLoader;
	MediaPlayer mediaPlayer;
	Text volumeLabel;
	Text levelLabel;
	Text scoreLabel;
	Text timeLabel;
	Timeline pointCheck;
	
	
	StackPane rootPane;
	BorderPane gamePane;
	GridPane menuPane;
	StackPane pauseMenu;
	FadeTransition showPauseMenu;
	Text pauseLevelLabel;
	Text pauseText;
	Button nextButton;
	Button replayButton;
	Button continueButton;
	Button levelsButton;
	
	Board gameBoard;
	
	public void start(Stage primaryStage) throws Exception {

		rootPane = new StackPane();
		gamePane = new BorderPane();
		StackPane centerPane = new StackPane();
		
		// loading level 1
		levelLoader = new LevelLoader();
		
		// adding grid
		gameBoard = new Board(levelLoader);
		
		Rectangle boardBG = new Rectangle(0,0,630,570);
		boardBG.setFill(Color.BLACK);
		boardBG.setArcHeight(50);
		boardBG.setArcWidth(50);
		boardBG.setOpacity(.5);
		centerPane.getChildren().addAll(boardBG,gameBoard);
		gamePane.setCenter(centerPane);
		
		FlowPane leftPane = new FlowPane();
		leftPane.setPadding(new Insets(0,50,0,0));
		URL resource;
		Media media;
		resource = getClass().getResource("song.mp3");
		media = new Media(resource.toString());
		mediaPlayer = new MediaPlayer(media);
		mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
		mediaPlayer.play();
	
		// add volume controls
		Slider slider = new Slider();
		slider.setMin(0.0);
		slider.setMax(.25);
		slider.setValue(slider.getMax() / 3.0);
		mediaPlayer.setVolume(slider.getValue());
		slider.setShowTickLabels(false);
		slider.setShowTickMarks(false);
		slider.setBlockIncrement(.01);
		slider.setOrientation(Orientation.VERTICAL);
		slider.setMaxHeight(100);
		slider.valueProperty().addListener(e -> {
			double value = slider.getValue();
			mediaPlayer.setVolume(value);
			if (value != 0.0) {
				int colorValue = (int) ((value)/slider.getMax()*260);
				if (colorValue > 0 && colorValue <= 255) {
					volumeLabel.setFill(Color.rgb(0, colorValue, 0));
				} else {
					volumeLabel.setFill(Color.rgb(255, 0, 0));
				}
			} else {
				volumeLabel.setFill(Color.rgb(0, 0, 255));
			}
		});
		slider.setPadding(new Insets(5));
		volumeLabel = new Text("Volume");
		volumeLabel.setFont(Font.font("Impact"));
		
		
		
		Button pauseButton = new Button();
		pauseButton.setStyle("-fx-background-color: transparent;");
		Image menuButtonIcon = new Image(getClass().getResourceAsStream("pauseButton.png")); // creates
		ImageView menuButtonIconView = new ImageView(menuButtonIcon);
		pauseButton .setGraphic(menuButtonIconView);
		pauseButton .setOnMouseEntered(e->{
			pauseButton.setEffect(new DropShadow());
		});
		pauseButton .setOnMouseExited(e->{
			pauseButton.setEffect(null);
		});
		
		pauseButton.setOnMouseClicked(e->{
			//pause stuff
			if(pauseMenu.isVisible()) {
				return;
			}
			
			pauseText.setText("Paused");
			showMenuButtons(true,false,true,true);
			gameBoard.stopClock();
			pointCheck.stop();
		});
		leftPane.setAlignment(Pos.TOP_RIGHT);
		leftPane.getChildren().addAll(pauseButton,slider,volumeLabel);
		gamePane.setLeft(leftPane);

		
		
		
		FlowPane rightPane = new FlowPane();
		rightPane.setPadding(new Insets(0,0,0,50));
		levelLabel = new Text("Level: XXXX");
		levelLabel.setFill(Color.WHITE);
		levelLabel.setEffect(new DropShadow());
		scoreLabel = new Text("Score: XXXX");
		scoreLabel.setFill(Color.WHITE);
		scoreLabel.setEffect(new DropShadow());
		timeLabel = new Text("Time: XXXX");
		timeLabel.setFill(Color.WHITE);
		timeLabel.setEffect(new DropShadow());
		
		pointCheck = new Timeline(new KeyFrame(
		        Duration.millis(1000),e -> {
		        	int score = gameBoard.getTotalPoints();
		        	int time = (int)gameBoard.getTime();	
		        	int levelNumber = levelLoader.getCurrentLevelNumber();
		        	levelLabel.setText("Level: " + levelNumber);
		        	int requiredScore = levelLoader.getRequiredLevelPoints(levelNumber);
		        	
		        	scoreLabel.setText("Score: " + score + "/" + requiredScore);	
		        	
		        	boolean levelCompleted = score>=requiredScore;
		        	if(time<=0 || levelCompleted) {
		        		levelLoader.loadLevel(gameBoard, -1);
		        		if(levelCompleted) {
		        			pauseText.setText("Level Completed!");
		        			showMenuButtons(false,true,true,true);
		        		} else {
		        			pauseText.setText("Nice Try!");
		        			showMenuButtons(false,false,true,true);
		        		}
		        	}
		        	timeLabel.setText("Time: " + time);
		        	
		        }));
		
		
		pointCheck.setCycleCount(Animation.INDEFINITE);
		scoreLabel.setFont(Font.font("Impact",24));
		levelLabel.setFont(Font.font("Impact",24));
		timeLabel.setFont(Font.font("Impact",24));
		
		VBox vbox = new VBox();
		vbox.setPadding(new Insets(10));
		vbox.setSpacing(10);
		vbox.getChildren().addAll(levelLabel,scoreLabel,timeLabel);
		rightPane.setAlignment(Pos.TOP_LEFT);
		rightPane.getChildren().addAll(vbox);
		gamePane.setRight(rightPane);
		
		pauseMenu = new StackPane();
		pauseMenu.setAlignment(Pos.CENTER);
		pauseText = new Text("Nice Try!");
		pauseText.setEffect(new DropShadow());
		pauseText.setFill(Color.WHITE);
		pauseText.setFont(Font.font("Impact",48));
		Rectangle box = new Rectangle(0,0,450,250);
		box.setFill(Color.BLACK);
		box.setArcHeight(50);
		box.setArcWidth(50);
		box.setOpacity(.5);
		VBox items = new VBox();
		items.setAlignment(Pos.CENTER);
		items.setPadding(new Insets(50));
		
		replayButton = new Button();
		replayButton.setStyle("-fx-background-color: transparent;");
		Image replayButtonIcon = new Image(getClass().getResourceAsStream("replayButton.png")); // creates
		ImageView replayButtonIconView = new ImageView(replayButtonIcon);
		replayButton.setGraphic(replayButtonIconView );
		replayButton.setOnMouseEntered(e->{
			replayButton.setEffect(new DropShadow());
		});
		replayButton.setOnMouseExited(e->{
			replayButton.setEffect(null);
		});
		
		replayButton.setOnMouseClicked(e->{
			this.showMenuButtons(false, false, false, false);
			levelLoader.loadLevel(gameBoard, levelLoader.getCurrentLevelNumber()-1);
			gameBoard.startClock();
		});
		
		continueButton = new Button();
		continueButton.setStyle("-fx-background-color: transparent;");
		Image continueButtonIcon = new Image(getClass().getResourceAsStream("continueButton.png")); // creates
		ImageView continueButtonIconView = new ImageView(continueButtonIcon);
		continueButton.setGraphic(continueButtonIconView );
		continueButton.setOnMouseEntered(e->{
			continueButton.setEffect(new DropShadow());
		});
		continueButton.setOnMouseExited(e->{
			continueButton.setEffect(null);
		});
		
		continueButton.setOnMouseClicked(e->{
			this.showMenuButtons(false, false, false, false);
			gameBoard.continueClock();
		});
		
		levelsButton = new Button();
		levelsButton.setStyle("-fx-background-color: transparent;");
		Image levelsButtonIcon = new Image(getClass().getResourceAsStream("menuButton.png")); // creates
		ImageView levelsButtonIconView = new ImageView(levelsButtonIcon);
		levelsButton.setGraphic(levelsButtonIconView );
		levelsButton.setOnMouseEntered(e->{
			levelsButton.setEffect(new DropShadow());
		});
		levelsButton.setOnMouseExited(e->{
			levelsButton.setEffect(null);
		});
		
		levelsButton.setOnMouseClicked(e->{
			gamePane.setVisible(false);
			levelLoader.loadLevel(gameBoard, -1);
			gameBoard.stopClock();
			pointCheck.stop();
			menuPane.setVisible(true);

			pauseMenu.setOpacity(0.0);
			pauseMenu.setVisible(false);
			gameBoard.setOpacity(1.0);
		});
		
		nextButton = new Button();
		nextButton.setStyle("-fx-background-color: transparent;");
		Image nextButtonIcon = new Image(getClass().getResourceAsStream("nextButton.png")); // creates
		ImageView nextButtonIconView = new ImageView(nextButtonIcon);
		nextButton.setGraphic(nextButtonIconView );
		nextButton.setOnMouseEntered(e->{
			nextButton.setEffect(new DropShadow());
		});
		nextButton.setOnMouseExited(e->{
			nextButton.setEffect(null);
		});
		
		nextButton.setOnMouseClicked(e->{
			this.showMenuButtons(false, false, false, false);
			levelLoader.loadLevel(gameBoard, levelLoader.getCurrentLevelNumber());
			gameBoard.startClock();
		});
		
		
		
		pauseLevelLabel = new Text("Level: XXXX");
		pauseLevelLabel.setFill(Color.WHITE);
		pauseLevelLabel.setFont(Font.font("Impact",24));
		
		items.setSpacing(10);
		HBox hButtons = new HBox();
		hButtons.setAlignment(Pos.CENTER);
		hButtons.getChildren().addAll(levelsButton,continueButton,replayButton,nextButton);
		items.getChildren().addAll(pauseText,pauseLevelLabel,hButtons);
		pauseMenu.getChildren().addAll(box,items);
		pauseMenu.setVisible(false);
		pauseMenu.setOpacity(0.0);
		centerPane.getChildren().add(pauseMenu);
		
		showPauseMenu = new FadeTransition(Duration.millis(500), pauseMenu);
		showPauseMenu.setFromValue(0.0);
		showPauseMenu.setToValue(1.0);
		
		
		
		menuPane = new GridPane();
		menuPane.setAlignment(Pos.CENTER);
		
		Image logoIcon = new Image(getClass().getResourceAsStream("MacMashLogo.png")); // creates
		ImageView logoIconView = new ImageView(logoIcon);
		logoIconView.setEffect(new DropShadow());
		logoIconView.setFitWidth(500);
		logoIconView.setFitHeight(266);
		menuPane.add(logoIconView, 0, 0);
		
		VBox menuItems = new VBox();
		menuItems.setAlignment(Pos.CENTER);
		Button playerButton = new Button();
		playerButton.setStyle("-fx-background-color: transparent;");
		Image playerButtonIcon = new Image(getClass().getResourceAsStream("playButton.png")); // creates
		ImageView playerButtonIconView = new ImageView(playerButtonIcon);
		playerButton.setGraphic(playerButtonIconView);
		menuItems.getChildren().add(playerButton);
		menuPane.add(menuItems, 0, 1);
		
		playerButton.setOnMouseEntered(e->{
			playerButton.setEffect(new DropShadow());
		});
		playerButton.setOnMouseExited(e->{
			playerButton.setEffect(null);
		});

		playerButton.setOnMouseClicked(e->{
			gamePane.setVisible(true);
			levelLoader.loadLevel(gameBoard, 0);
			gameBoard.startClock();
			pointCheck.play();
			menuPane.setVisible(false);
		});
		
//		Image logoBG = new Image(getClass().getResourceAsStream("logosBackground.png")); // creates
//		ImageView logoBGView = new ImageView(logoBG);
//		rootPane.getChildren().addAll(logoBGView);
		
		Image BG = new Image(getClass().getResourceAsStream("Background.png")); // creates
		ImageView BGView = new ImageView(BG);
		BGView.fitWidthProperty().bind(rootPane.widthProperty());
		BGView.fitHeightProperty().bind(rootPane.widthProperty().multiply(6.64451827));
		rootPane.setAlignment(Pos.BOTTOM_CENTER);
		rootPane.getChildren().addAll(BGView);
		
		gamePane.setVisible(false);
		rootPane.getChildren().addAll(gamePane,menuPane);
		Scene gameScene = new Scene(rootPane, 800, 600);
		Image cursorIcon = new Image(getClass().getResourceAsStream("cursor.png"));
		gameScene.setCursor(new ImageCursor(cursorIcon));
		primaryStage.setScene(gameScene);
		primaryStage.show();
		primaryStage.setMinHeight(625);
		primaryStage.setMinWidth(950);
		primaryStage.setTitle("The MAC Mash - CPS240");
		primaryStage.setFullScreen(true);
		Image windowIcon = new Image(getClass().getResourceAsStream("MacMashSmallLogo.png")); // creates
		primaryStage.getIcons().add(windowIcon);

//		Line bgPath = new Line(rootPane.widthProperty().doubleValue()*.75,
//				logoBG.getHeight()/2,
//				rootPane.widthProperty().doubleValue()*.5,
//				logoBG.getHeight()/2);
//		PathTransition bgScroll = new PathTransition(Duration.seconds(10),
//				bgPath,
//				logoBGView);
//		bgScroll.setAutoReverse(true);
//		bgScroll.setInterpolator(Interpolator.LINEAR);
//		bgScroll.setCycleCount(Animation.INDEFINITE);
//		bgScroll.play();
		
	}

	public static void main(String[] args) {
		launch();
	}
	
	public void showMenuButtons(boolean showContinue,boolean showNext,boolean showReplay,boolean showLevels) {
		nextButton.setVisible(showNext);
		replayButton.setVisible(showReplay);
		continueButton.setVisible(showContinue);
		levelsButton.setVisible(showLevels);
		
		if(showContinue||showNext||showReplay||showLevels) {
			pointCheck.stop();
    		gameBoard.stopClock();
    		pauseLevelLabel.setText("Level: " + levelLoader.getCurrentLevelNumber()+
    				"\nScore: " + gameBoard.getTotalPoints() + "/"+ levelLoader.getRequiredLevelPoints(levelLoader.getCurrentLevelNumber()) +
    				"\nTime: " + (int)gameBoard.getTime());
    		pauseMenu.setVisible(true);
    		gameBoard.setOpacity(.5);
    		showPauseMenu.play();
		} else if(!(showContinue&&showNext&&showReplay&&showLevels)) {
    		pointCheck.play();
    		
			pauseMenu.setOpacity(0.0);
			pauseMenu.setVisible(false);
			gameBoard.setOpacity(1.0);
		}
		
		
		
	}
	

}
