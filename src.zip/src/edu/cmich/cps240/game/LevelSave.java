package edu.cmich.cps240.game;

import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;

public class LevelSave {
	
	File file = new File("highScores.txt");
	
	//Constructor
	public LevelSave(){
		
	}
	
	public void saveLevel(int time, int score) throws IOException{
		FileWriter fw = new FileWriter(file, true);
		Scanner scan = new Scanner(file);
		//Convert time-in-milliseconds to formatted time
		String gameTime = formatTime(time);
		
		//Check if file exists
		fileExists(fw, scan);
		//Write to file
		fw.write("\n" + score + "\t\t" + gameTime);
		//Save/close file
		fw.close();
	}
	
	/*
	 * Will check if file exists
	 * will create file is none exists
	 * */
	private void fileExists(FileWriter fw, Scanner scan) throws IOException{
		if(!file.exists()){
			//Create file if none exists
			file.createNewFile();
			//Prints first lines to file 
			fw.write("SCORE\t\tTIME"
					+ "\n---------------------");
		}else if(!scan.hasNextLine()){
			//Prints first lines to file if file empty
			fw.write("SCORE\t\tTIME"
					+ "\n---------------------");
		}
	}
	
	/*
	 * Convert milliseconds to minutes and seconds
	 * returns as mins and secs to two decimal places
	 * */
	private String formatTime(int time){
		String minutes = String.format("%02d", (time/1000)/60);
		String seconds = String.format("%02d", (time/1000)%60);
		return minutes + ":" + seconds;
	}
	
}
