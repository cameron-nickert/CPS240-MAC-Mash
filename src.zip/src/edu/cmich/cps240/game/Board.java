package edu.cmich.cps240.game;

import edu.cmich.cps240.*;
import edu.cmich.cps240.logos.Logo;
import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.PathTransition;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Line;
import javafx.util.Duration;

public class Board extends GridPane {

	public int clickNumber = 0;
	public Logo firstClickedLogo;
	public Logo secondClickedLogo;

	
	public boolean isClearing = false;
	public boolean buttonsEnabled = true;

	int totalPoints = 0;
	private double time = 0.0;
	
	LevelLoader levelLoader;

	public Board(LevelLoader levelLoader) {

		this.levelLoader = levelLoader;

		this.setPadding(Insets.EMPTY);

		this.setAlignment(Pos.CENTER);

		// new Image(url)
		// Image bgImage = new Image(getClass().getResourceAsStream("bg1.png"));
		// // new BackgroundSize(width, height, widthAsPercentage,
		// heightAsPercentage, contain, cover)
		// BackgroundSize backgroundSize = new BackgroundSize(.1,.1,
		// false,false,true, false);
		// BackgroundImage backgroundImage = new BackgroundImage(bgImage,
		// BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,
		// BackgroundPosition.CENTER,backgroundSize);
		// Background background = new Background(backgroundImage);
		// this.setBackground(background);
	}

	// this function swaps the two logos firstClickedLogo and secondClickedLogo
	PathTransition pt; // these two are animations
	PathTransition pt2;
	PathTransition pt3;
	PathTransition pt4;

	Logo tempLogo;

	public void swapTwoLogos() {
		// sets the first buttons index to the second button

		switchTwoLogoValues();
		// tile one animation
		pt = getLogoPath(1, 300);
		pt.setCycleCount(1);
		pt2 = getLogoPath(2, 300);
		pt2.setCycleCount(1);

		pt3 = getLogoPath(3, 300);
		pt3.setCycleCount(1);
		pt4 = getLogoPath(4, 300);
		pt4.setCycleCount(1);

		pt2.setOnFinished(new EventHandler<ActionEvent>() {

			public void handle(ActionEvent event) {
				if(firstClickedLogo==null ||secondClickedLogo==null) {
					return;
				}
				int points = getPointsAndRemove(firstClickedLogo);
				points += getPointsAndRemove(secondClickedLogo);
				if (points > 0) {
					totalPoints += points;
					addClock(points*.0075);
					clickDefaults();
				} else { // if neither of them get you points, switch them back
					pt3.play();
					pt4.play();
				}

			}
		});

		pt4.setOnFinished(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				switchTwoLogoValues();
				
				int points = getPointsAndRemove(firstClickedLogo);
				points += getPointsAndRemove(secondClickedLogo);
				if (points > 0) {
					totalPoints += points;
					addClock(points*.0075);
				}
				clickDefaults();
			}
		});

		pt.play();
		pt2.play();

	}

	public void clickDefaults() {
		if (firstClickedLogo != null) {
			firstClickedLogo.setTranslateX(0);
			firstClickedLogo.setTranslateY(0);
			firstClickedLogo.setEffect(null);
			firstClickedLogo = null;
		}
		if (secondClickedLogo != null) {
			secondClickedLogo.setTranslateX(0);
			secondClickedLogo.setTranslateY(0);
			secondClickedLogo.setEffect(null);
			secondClickedLogo = null;
		}
		clickNumber = 0;
		buttonsEnabled = true;
	}

	private void switchTwoLogoValues() {
		if(firstClickedLogo==null||secondClickedLogo==null) {
			return;
		}
		GridPane.setColumnIndex(firstClickedLogo, secondClickedLogo.getPhyX());
		GridPane.setRowIndex(firstClickedLogo, secondClickedLogo.getPhyY());

		// sets the second buttons index to the first button (first
		// index was stored in temp)
		GridPane.setColumnIndex(secondClickedLogo, firstClickedLogo.getPhyX());
		GridPane.setRowIndex(secondClickedLogo, firstClickedLogo.getPhyY());

		// sets the physical positions to there new spots
		firstClickedLogo.setPhyX(GridPane.getColumnIndex(firstClickedLogo));
		firstClickedLogo.setPhyY(GridPane.getRowIndex(firstClickedLogo));
		secondClickedLogo.setPhyX(GridPane.getColumnIndex(secondClickedLogo));
		secondClickedLogo.setPhyY(GridPane.getRowIndex(secondClickedLogo));

		// this changes the logical values of the logos
		firstClickedLogo.setX(firstClickedLogo.getPhyX());
		secondClickedLogo.setX(secondClickedLogo.getPhyX());

		int yDifference = firstClickedLogo.getPhyY() - secondClickedLogo.getPhyY();
		firstClickedLogo.setY(firstClickedLogo.getY() + yDifference);

		yDifference = secondClickedLogo.getPhyY() - firstClickedLogo.getPhyY();
		secondClickedLogo.setY(secondClickedLogo.getY() + yDifference);
	}

	private PathTransition getLogoPath(int desiredPathIndex, long millis) {
		if (desiredPathIndex == 1) {
			return new PathTransition(Duration.millis(300),
					new Line(
							-firstClickedLogo.getPhyX() * firstClickedLogo.getWidth()
									+ secondClickedLogo.getPhyX() * firstClickedLogo.getWidth()
									+ firstClickedLogo.getWidth() / 2.0,
							-firstClickedLogo.getPhyY() * firstClickedLogo.getHeight()
									+ secondClickedLogo.getPhyY() * firstClickedLogo.getHeight()
									+ firstClickedLogo.getHeight() / 2.0,
							firstClickedLogo.getWidth() / 2.0, firstClickedLogo.getHeight() / 2.0),
					firstClickedLogo);
		} else if (desiredPathIndex == 2) {
			return new PathTransition(Duration.millis(millis),
					new Line(
							-secondClickedLogo.getPhyX() * secondClickedLogo.getWidth()
									+ firstClickedLogo.getPhyX() * secondClickedLogo.getWidth()
									+ secondClickedLogo.getWidth() / 2.0,
							-secondClickedLogo.getPhyY() * secondClickedLogo.getHeight()
									+ firstClickedLogo.getPhyY() * secondClickedLogo.getHeight()
									+ secondClickedLogo.getHeight() / 2.0,
							secondClickedLogo.getWidth() / 2.0, secondClickedLogo.getHeight() / 2.0),
					secondClickedLogo);
		} else if (desiredPathIndex == 3) {
			return new PathTransition(Duration.millis(millis),
					new Line(firstClickedLogo.getWidth() / 2.0, firstClickedLogo.getHeight() / 2.0,
							-firstClickedLogo.getPhyX() * firstClickedLogo.getWidth()
									+ secondClickedLogo.getPhyX() * firstClickedLogo.getWidth()
									+ firstClickedLogo.getWidth() / 2.0,
							-firstClickedLogo.getPhyY() * firstClickedLogo.getHeight()
									+ secondClickedLogo.getPhyY() * firstClickedLogo.getHeight()
									+ firstClickedLogo.getHeight() / 2.0),
					firstClickedLogo);
		} else if (desiredPathIndex == 4) {
			return new PathTransition(Duration.millis(millis),
					new Line(secondClickedLogo.getWidth() / 2.0, secondClickedLogo.getHeight() / 2.0,
							-secondClickedLogo.getPhyX() * secondClickedLogo.getWidth()
									+ firstClickedLogo.getPhyX() * secondClickedLogo.getWidth()
									+ secondClickedLogo.getWidth() / 2.0,
							-secondClickedLogo.getPhyY() * secondClickedLogo.getHeight()
									+ firstClickedLogo.getPhyY() * secondClickedLogo.getHeight()
									+ secondClickedLogo.getHeight() / 2.0),
					secondClickedLogo);
		} else {
			return null;
		}

	}

	public int getPointsAndRemove(Logo root) {
		Logo[] directions = new Logo[4];
		directions = root.getDirections(this); // this returns the logos around
												// this one
		Logo onLeft = directions[0], onRight = directions[1], onUp = directions[2], onDown = directions[3];
		directions = null;

		Logo[] alreadyChecked = null;
		int points = 0;
		int horizontal = 1; // starts at 1 because it counts itself
		int vertical = 1;

		while (onLeft != null && !isLogoInsideArray(onLeft, alreadyChecked)) {
			alreadyChecked = addLogoInsideArray(onLeft, alreadyChecked);
			horizontal++;
			directions = onLeft.getDirections(this); // this returns the logos
														// around this one
			onLeft = directions[0];
		}
		while (onRight != null && !isLogoInsideArray(onRight, alreadyChecked)) {
			alreadyChecked = addLogoInsideArray(onRight, alreadyChecked);
			horizontal++;
			directions = onRight.getDirections(this); // this returns the logos
														// around this one
			onRight = directions[1];
		}

		// remove logos and add points
		boolean rootRemoved = false;
		if (horizontal >= 3) {
			for (int i = 0; i < alreadyChecked.length; i++) {
				// add new logo
				int x = alreadyChecked[i].getPhyX();
				int y = alreadyChecked[i].getPhyY();
				Logo newLogo = levelLoader.getRandomLogo(this);
				newLogo.setX(alreadyChecked[i].getX());
				newLogo.setY(alreadyChecked[i].getY());
				newLogo.setPhyX(alreadyChecked[i].getPhyX());
				newLogo.setPhyY(alreadyChecked[i].getPhyY());
				// remove
				this.remove(alreadyChecked[i], newLogo, x, y);
			}
			// shift others down before you remove

			// add new logo
			int x = root.getPhyX();
			int y = root.getPhyY();
			Logo newLogo = levelLoader.getRandomLogo(this);
			newLogo.setX(root.getX());
			newLogo.setY(root.getY());
			newLogo.setPhyX(root.getPhyX());
			newLogo.setPhyY(root.getPhyY());
			// remove
			this.remove(root, newLogo, x, y);
			rootRemoved = true;
			points += horizontal * 100;
		}

		alreadyChecked = null;
		while (onUp != null && !isLogoInsideArray(onUp, alreadyChecked)) {
			alreadyChecked = addLogoInsideArray(onUp, alreadyChecked);

			vertical++;
			directions = onUp.getDirections(this); // this returns the logos
													// around this one
			onUp = directions[2];
		}
		while (onDown != null && !isLogoInsideArray(onDown, alreadyChecked)) {
			alreadyChecked = addLogoInsideArray(onDown, alreadyChecked);
			vertical++;
			directions = onDown.getDirections(this); // this returns the logos
														// around this one
			onDown = directions[3];
		}

		// remove logos and add pointt
		if (vertical >= 3) {
			for (int i = 0; i < alreadyChecked.length; i++) {
				// add new logo
				int x = alreadyChecked[i].getPhyX();
				int y = alreadyChecked[i].getPhyY();
				Logo newLogo = levelLoader.getRandomLogo(this);
				newLogo.setX(alreadyChecked[i].getX());
				newLogo.setY(alreadyChecked[i].getY());
				newLogo.setPhyX(alreadyChecked[i].getPhyX());
				newLogo.setPhyY(alreadyChecked[i].getPhyY());
				// remove
				this.remove(alreadyChecked[i], newLogo, x, y);
			}
			// add new logo
			if (!rootRemoved) {
				int x = root.getPhyX();
				int y = root.getPhyY();
				Logo newLogo = levelLoader.getRandomLogo(this);
				newLogo.setX(root.getX());
				newLogo.setY(root.getY());
				newLogo.setPhyX(root.getPhyX());
				newLogo.setPhyY(root.getPhyY());

				// remove
				this.remove(root, newLogo, x, y);
			}
			points += vertical * 100;
		}

		return points;

	}

	// this method returns true if the logo is inside the logo array
	public boolean isLogoInsideArray(Logo possibleLogo, Logo[] logosToCheck) {
		if (logosToCheck == null) {
			return false;
		}
		for (int i = 0; i < logosToCheck.length; i++) {
			if (logosToCheck[i].equals(possibleLogo)) {
				return true;
			}
		}
		return false;
	}

	// this method returns true if the logo is inside the logo array
	public Logo[] addLogoInsideArray(Logo addingLogo, Logo[] logos) {
		Logo[] newLogos;

		if (logos == null) {
			newLogos = new Logo[1];
			newLogos[0] = addingLogo;
			return newLogos;
		}
		newLogos = new Logo[logos.length + 1];
		for (int i = 0; i < logos.length; i++) {
			newLogos[i] = logos[i];
		}
		newLogos[logos.length] = addingLogo;
		return newLogos;
	}

	public int getTotalPoints() {
		return totalPoints;
	}

	
	public void add(Logo newLogo, int columnIndex, int rowIndex) {
		if(this.isClearing) {
			return;
		}
		
		
		ObservableList<Node> logos = this.getChildren();
		for (Node node : logos) {
			Logo logo = (Logo) node;
			if(logo.getX()==columnIndex && logo.getY()==rowIndex && !logo.isRemoving) {
				return;
			}
		}
		
		
		newLogo.isAnimated= true;
		newLogo.setOpacity(0.0);
		FadeTransition fade = new FadeTransition(Duration.millis(500), newLogo);
		fade.setFromValue(0.0);
		fade.setToValue(1.0);
		
		super.add(newLogo, columnIndex, rowIndex);
		fade.setDelay(Duration.millis(500));
		
		fade.setOnFinished(e -> {
			getPointsAndRemove(newLogo);
			newLogo.isAnimated= false;
		});
		
		RotateTransition rotate = new RotateTransition(Duration.millis(500), newLogo);
		rotate.setFromAngle(180);
		rotate.setToAngle(0);
		rotate.setDelay(Duration.millis(500));
		
		rotate.play();
		fade.play();

	}

	public void remove(Logo child, Logo newLogo, int newX, int newY) {
		child.isRemoving = true;
		FadeTransition fade = new FadeTransition(Duration.millis(500), child);
		fade.setFromValue(1.0);
		fade.setToValue(0.0);
		fade.setOnFinished(e -> {
			this.getChildren().remove(child);
			if(newLogo!=null) {
				this.add(newLogo, newX, newY);
			}
		});
		
		
		RotateTransition rotate = new RotateTransition(Duration.millis(500), child);
		rotate.setToAngle(360);
		
		rotate.play();
		fade.play();

	}

	Timeline timeIncrement = new Timeline(new KeyFrame(
	        Duration.millis(100),e -> {
	        	time-=.1;		        	
	        	}));
	
	public void startClock() {
		stopClock();
		totalPoints = 0;
		time = levelLoader.getCurrentLevelNumber()<10 ? 30-levelLoader.getCurrentLevelNumber()*2:10;
		timeIncrement.setCycleCount(Animation.INDEFINITE);
		timeIncrement.play();
	}
	
	public void addClock(double timeAdded) {
		time += timeAdded;
	}
	
	public void stopClock() {
		timeIncrement.stop();
	}
	
	public void continueClock() {
		stopClock();
		timeIncrement.setCycleCount(Animation.INDEFINITE);
		timeIncrement.play();
	}

	public double getTime() {
		return time;
	}

	public void setTime(double time) {
		this.time = time;
	}
	
}
