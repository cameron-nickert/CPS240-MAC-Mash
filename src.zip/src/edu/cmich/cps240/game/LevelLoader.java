package edu.cmich.cps240.game;

import java.net.URL;

import edu.cmich.cps240.logos.*;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.Node;
import javafx.scene.layout.GridPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

public class LevelLoader {

	final private char cmuChar = 'C';
	final private char wmuChar = 'W';
	final private char emuChar = 'E';
	final private char ballChar = 'B';
	final private char tolChar = 'T';
	final private char niuChar = 'N';

	final private String[] levelOne = {
			"ENCBCCTC",
			"NECBTTCB",
			"NETECTCW",
			"CCWTTNTC",
			"CCNNTNTC",
			"WBBCBTCN",
			"WWTCWEWC",
			"TCCWCTBC" };
	final private String[]  levelTwo =  {
			"CWEBTNWC",
			"WEBTNWCC",
			"WETBEECW",
			"NCNCCNBN",
			"NEWCENWC",
			"CCWTTCTC",
			"NECBTTCB",
			"ENCBCCTC" };
	final private String[] levelThree = {
			"ENCBCCTC",
			"NECBTTCB",
			"NETECTCW",
			"CCWTTNTC",
			"CCNNTNTC",
			"WBBCBTCN",
			"WWTCWEWC",
			"TCCWCTBC" };;
	final private String[] levelFour = {""};
	final private String[] levelFive = {""};
	final private String[] levelSix = {""};
	final private String[] levelSeven = {""};
	final private String[] levelEight = {""};
	final private String[] levelNine = {""};
	final private String[] levelTen = {""};

	private int currentLevel = 0;
	
	private String[][] levels = {levelOne,levelTwo};
	
    
	
	public int getCurrentLevelNumber() {
		return currentLevel;
	}

	public int getCurrentLevelHeight() {
		return levels[currentLevel-1].length;
	}
	
	public int getCurrentLevelPhyHeight() {
		return 8;
	}

	public int getCurrentLevelWidth() {
		return levels[currentLevel-1][0].length();
	}

	
	public int getRequiredLevelPoints(int level) {
		return 700+(level*100);
	}
	
	public Logo getRandomLogo(Board board) {

		int randomInt = (int)(Math.random()*6)+1;
		Logo newLogo = null;
		
		if (randomInt==1) {
			newLogo = new CMU(board);
		} else if (randomInt==2) {
			newLogo = new WMU(board);
		} else if (randomInt==3) {
			newLogo = new EMU(board);
		} else if (randomInt==4) {
			newLogo = new BSU(board);
		} else if (randomInt==5) {
			newLogo = new TOL(board);
		} else if (randomInt==6) {
			newLogo = new NIU(board);
		}
	
		return newLogo;
	}
	
	public void loadLevel(Board board, int levelIndex) {
		board.isClearing = true;
		board.clickDefaults();
		for(Node node: board.getChildren()){
			Logo logoNode = (Logo)node;
			board.remove(logoNode, null, 0, 0);
		}
		
		boolean levelCreated = false;
		if(levelIndex<0) {
			return;
		} else if(levelIndex>=levels.length) {
			currentLevel = levelIndex + 1;
			levelCreated = false;
			levelIndex = 0;
		} else{
			levelCreated = true;
			currentLevel = levelIndex + 1;
		}
		board.isClearing = false;
		for (int i = 0; i < levels[levelIndex].length; i++) { //levels[levelIndex] gets the level array
			for (int j = 0; j < levels[levelIndex][i].length(); j++) {
				char currentLogoChar = levels[levelIndex][i].charAt(j);
				Logo newLogo;
				
				if (currentLogoChar == cmuChar) {
					newLogo = new CMU(board);
				} else if (currentLogoChar == wmuChar) {
					newLogo = new WMU(board);
				} else if (currentLogoChar == emuChar) {
					newLogo = new EMU(board);
				} else if (currentLogoChar == ballChar) {
					newLogo = new BSU(board);
				} else if (currentLogoChar == tolChar) {
					newLogo = new TOL(board);
				} else if (currentLogoChar == niuChar) {
					newLogo = new NIU(board);
				} else {
					newLogo = null;
				}
				
				if(!levelCreated) {
					newLogo = this.getRandomLogo(board);
				}
				
				newLogo.setX(j); //this is the logical placement of the logos
				newLogo.setY(i);
				newLogo.setPhyX(j); //this is the physical placement that the user see's
				newLogo.setPhyY(i);
				board.add(newLogo, newLogo.getPhyX(), newLogo.getPhyY());
				
			}

		}

	}

}
